package jracket;

public class Main {

    public static void main(String[] args) {
        Interpreter interp = new Interpreter();
        interp.run();
    }

}
